======================================
====== BONES ITEM PACK - README ======
======================================

Contents:								
---------								
1: Important Information				
2: Installation	
3: Installation (Mod Compatible)
4: Json Save Files		
5: Optional Settings		
6: Drop Locations Guide (Spoiler Free)
7: Credits & Contact Info
8: A Note To Modders
	
	
	
===== 1: Important Information =====

If you read anything from this file, please let it be this:

This mod will not work if you have disabled startup movies. 
To ensure it is disabled, go to your WillowEngine.ini file,
(Documents\My Games\Borderlands 2\WillowGame\Config\WillowEngine.ini),
ensure that bForceNoMovies is set to False. 

This mod is able to run alongside other mods, both SDK and Text mods. 
Note that there is no guarenteed compatibility between mods, and may still have unintended results.
Please view the alternate installation instructions below to ensure maximum compatibility.

This mod utilizes .Json save files to save the player's inventory, alongside .Sav files.
Please view below for more details.

Thank you for downloading, and have fun!



===== 2: Installation =====

These directions are inteded for the Steam version of BL2 on Windows.
Installation paths and methods may vary depending on game platform and OS!

1 - Install the BL2 Python SDK
Visit https://github.com/bl-sdk/PythonSDK and follow the installation instructions.
If installed correctly, you will see a Mods tab on the main menu.

2 - Install BonesItemPack to your Mods folder.
Extract the folder "BonesItemPack" to your BL2's "Mods" folder
(Steam\steamapps\common\Borderlands 2\Binaries\Win32\Mods)

3 - Enable the mod ingame.
In the main menu, enter the Mods tab and enable the Bones Item Pack mod.
Remember that you will need to do this every time you relaunch the game.
If all is done correctly, a confirmation message will display when you load into the game.

Optional - Set the optional settings in the BLCM file.
You can open the BLCM file included with this mod
(found in: Steam\steamapps\common\Borderlands 2\Binaries\Win32\Mods\BonesWeaponPack\Source).
You can toggle options on weapon descriptions and drop sources.

Optional - Install the included save files.
Included with this mod is a save file containing every new weapon.
To install the SAV file, place the file in: Documents\my games\borderlands 2\willowgame\savedata\[YOUR_STEAM_ID]
To install the JSON file, place the file in: Steam\steamapps\common\Borderlands 2\Binaries\Win32\Mods\BonesItemPack\Saves
Remember to back up your original saves just in case!



===== 3: Installation (Mod Compatible) =====

This mod is able to run alongside other mods, both SDK and Text mods.
Please note that there is no guarenteed compatibility, and issues may still occur. 
Remember to set the Gold Chest optional category in the .Blcm file to ensure drop source compatibility. 

- If playing with SDK mods that use Constructor (Exodus, etc.):
Select the files in SDK Mod Compatiblity Files and place them in a new folder within the mod's main folder. 
Mods such as Exodus will come with a z_ModExtension_ folder, but if not, create a new folder and place the files there.
It is reccommended to start from a new save file when playing with this method, but not required (if not, be sure to back up your saves!)

- If playing with Text mods, or SDK mods that do not use Constructor (UCP, Reborn, etc.):
Install Bones Item Pack as normal.
You can either enable other mods through the mod manager, or execute the files through the console. 
You can also place text mod files within the ModExtensions folder of this mod, and they will automatically execute when Bones Item Pack is enabled.
If loading mods manually, it is recommended to load whichever mods you'd like to prioritize last, so that any commands are not potentially overwritten.



===== 4: Json Save Files =====

To allow the game to save our new guns, the mod needs to utilize a different type of save file.
The Constructor mod generates a .json file upon loading a save that will be referenced when playing with the mod enabled.
Your .sav files will still be used to save the rest of your character's information. If viewed in a save editor, however, you may find Unknown Weapon entries.
Opening the .json save file manually will allow you to edit your inventory, but you will need to know the names of the parts.
Use the object explorer in BLCMM and search "getall WeaponPartDefinition" and use Ctrl+F to search for specific parts.
Weapon parts specific to the mod are listed in the Wiki file.

If you load into a game on a character without enabling this mod, modded guns will be removed from your inventory. 
In this situation, first enable the mod in the mod manager, then hit the L key to load your Json save. 
Your modded weapons will be restored to the last point the .Json file was saved. Keep in mind that vanilla gear may be duplicated.

Included with this mod is a save file that includes all weapons.
To ensure this save file is installed correctly, remember to install both the .sav and .json files.

Note that modded weapons will lose their favorite / trash status upon reloading the game. 
In addition, weapons will not have their materials applied on the main menu.



===== 5: Optional Settings =====

You can open the .blcm file in BLCMM to view two optional modules.

- Weapon Effect Descriptions
Toggles between On and Off (On enabled by default).
When enabled, an extra line underneath the red text of the weapon will describe the weapon's stats and effects.
The wording intentionally uses broad terms to describe certain stats, but does not require the player to guess what it even does in the first place.
Disabling this option will return the item card to only display the red text, like how it is in the base game.

- Drop Sources
Toggles between Bosses and Gold Chest (Bosses enabled by default).
The Bosses option will assign an extra loot pool to a specific boss that contains a new item. 
This pool has a 20% chance to drop and does not have an effect on the chances of other dedicated drops.
The Gold Chest option assigns all weapons to the golden chest in Sanctuary. The golden chest will also be free to open.
When running this mod alongside other mods (especially large overhauls like UCP, Exodus, Reborn, etc.), it is highly recommended to enable the Gold Chest option.
This ensures that the changes to boss loot pool assignments will not be overwritten.



===== 6: Drop Locations Guide (Spoiler Free) =====

Below is a list of each boss that drops a new weapon if the "Bosses" option is enabled.
New weapons have a 20% chance to drop and do not have an effect on the chances of other dedicated drops.

- Bad Maw: Assault Rifle
- Black Queen: SMG
- Boll: Shotgun
- Bone Head 2.0: Pistol
- Doc Mercy: Shotgun
- Dukino's Mom: Sniper
- Foreman: Sniper
- Gettle: SMG
- Henry: Pistol
- Hunter Helquist: Assault Rifle
- King Mong: Assault Rifle
- Knuckle Dragger: Assault Rifle
- Laney White: SMG
- Madame Von Bartlesby: Sniper
- Mad Dog: Rocket Launcher
- Mad Mike: Rocket Launcher
- McNally: Sniper
- MidgeMong: SMG
- Mobley: SMG
- Mortar: Rocket Launcher
- Old Slappy: Sniper
- Rakkman: Shotgun
- Saturn: Shotgun
- Savage Lee: Pistol
- Scorch: Pistol
- Smash Head: Rocket Launcher
- Spycho: Pistol
- Wilhelm: Pistol



===== 7: Credits & Contact Info =====

This mod was created by: Dr. Bones
Constructor mod created by: Juso
Special thanks to Shadowevil for UCP skinpool fixes.
Also special thanks to the people over at the 'Shadowevil's Hideout' Discord for infinite amounts of modding wizardry.

I would love to hear your feedback about the mod! Your suggestions and criticisms are always appreciated, and help me improve as a modder.
You can message me directly on Discord at Dr. Bones#6139, or leave feedback on the mod page.
(Please do not ask me for technical support or installation help. I'm likely not the person to be asking for that kind of stuff.)



===== 8: A Note To Modders =====

Hello BL2 modders!

First off, thank you for downloading my mod. I encourage you to look through this mod and learn how it was made.
Much of what I learned how to do came from browsing the inner workings of other mods. If you do, you'll want to
browse through the .Blcm file, as that is where the set commands that define the mod are all located.
However, do note two minor flaws with the way this mod was created:

1. Objects have inconsistent outer package names
When assembling all of my old gun mods into constructor files, I constructed new versions of the objects with the same outer packages as the originals.
While this doesn't have any immediate ramifications ingame, it is very sloppy. Mods like Exodus do a much better job of organizing their outer packages.

2. Barrels have no attribute slot upgrades
This I kind of got lazy on. Every unique barrel has no inheret stat changes like how gun parts normally apply their stats.
Essentially, all barrels are just cosmetic, and outside of the unique effects, don't have an effect on the gun's stats.

I would also like to note that no plagarism was intented with this mod. If elements of this mod are directly similar to other mods,
it is purely by coincidence. Like I have stated above, I have learned what I know about modding by browsing mods from other people,
but I have never directly copied work from anyone.

Anyways, thanks again for downloading and playing.
Modding for BL2 has given me a wonderful outlet to express my creativity and I'm truly thankful for you sharing interests with someone like me.
I encourage you to finish and realse your own mods, no matter how big or small! I started off knowing nothing about modding, and if I can release a mod, then so can you!

If you're reading this far, then just know you're super cool and I love you <3
