This file contains the INT file that replaces the base colorblind text with a combination of color and rarity grade in the English version of Borderlands 2.

[NOTES]

This replacement will most likely revert it's changes if you check the integrity of the game cache (just like how it resets the hex-edit for the community patch.)
Redownload if you need to.

[HOW TO INSTALL]

Close your game before doing this. It is best that you do this or your game might break.

Make a backup of your existing WillowGame.INT file before doing this. (It's in Borderlands 2/WillowGame/Localization/INT) Put it somewhere safe.

Download the new WillowGame.INT and save it as; All Files. If you don't select All Files, it will save as a TXT, and you don't want that.

Copy the WillowGame.INT file included in this to Borderlands 2/WillowGame/Localization/INT and paste it there.If it notifies you that there already is a file with this name, choose to replace it instead.

Reload your game and witness a world where Colorblind colors and the rarity they represent can live in peace and harmony on ItemCards!

Enjoy.

======
Sheep=
======
